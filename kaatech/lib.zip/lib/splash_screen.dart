import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'features/auth/providers/auth_provider.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }

  Future<void> _navigate() async {
    // 1. Esperar los 3 segundos del splash sí o sí
    await Future.delayed(const Duration(seconds: 3));

    if (!mounted) return;

    // 2. Leer el status actual (el stream ya habrá respondido en 3s)
    final authProvider = context.read<AuthProvider>();
    AuthStatus status = authProvider.status;

    // 3. Si Firebase aún no respondió (muy raro), esperar un poco más
    if (status == AuthStatus.initial || status == AuthStatus.loading) {
      await Future.delayed(const Duration(seconds: 2));
      if (!mounted) return;
      status = context.read<AuthProvider>().status;
    }

    if (status == AuthStatus.authenticated) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const OnboardingScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0F2A14), Color(0xFF18361E), Color(0xFF1D4727)],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 170,
              width: 170,
              decoration: BoxDecoration(
                color: const Color(0xFFA4AD95),
                borderRadius: BorderRadius.circular(40),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.25),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: const Icon(Icons.spa, size: 90, color: Color(0xFF17381F)),
            ),
            const SizedBox(height: 35),
            const Text(
              "K'AATECH",
              style: TextStyle(
                color: Color(0xFFA4AD95),
                fontSize: 44,
                fontWeight: FontWeight.bold,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'PLANTAS MEDICINALES',
              style: TextStyle(
                color: Colors.white70,
                letterSpacing: 4,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 45),
            const CircularProgressIndicator(color: Color(0xFFA4AD95)),
          ],
        ),
      ),
    );
  }
}
